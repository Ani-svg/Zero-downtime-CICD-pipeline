import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import AddBeneficiary from "./pages/AddBeneficiary";
import AddMentor from "./pages/AddMentor";

function App() {
  return (
    <Router>
      <Routes>
        {/* Login */}
        <Route path="/" element={<Login />} />

        {/* Dashboard */}
        <Route path="/dashboard" element={<Dashboard />} />

        {/* Add Beneficiary */}
        <Route
          path="/add-beneficiary"
          element={<AddBeneficiary />}
        />

        {/* Add Mentor */}
        <Route
          path="/add-mentor"
          element={<AddMentor />}
        />

        {/* Redirect unknown routes */}
        <Route
          path="*"
          element={<Navigate to="/" replace />}
        />
      </Routes>
    </Router>
  );
}

export default App;
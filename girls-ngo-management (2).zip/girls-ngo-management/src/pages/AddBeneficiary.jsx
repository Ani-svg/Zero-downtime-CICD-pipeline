import { useState } from "react";
import Layout from "../components/Layout";
import PersonalDetails from "../components/PersonalDetails";
import DocumentsUpload from "../components/DocumentsUpload";
import "./AddBeneficiary.css";

export default function AddBeneficiary() {
  const [step, setStep] = useState(1);

  const [beneficiary, setBeneficiary] = useState({
    profilePicture: null,
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dob: "",
    gender: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    joiningDate: "",
  });

  const [documents, setDocuments] = useState({
    aadhaar: null,
    addressProof: null,
    birthCertificate: null,
  });

  const nextStep = () => {
    if (
      !beneficiary.firstName ||
      !beneficiary.lastName ||
      !beneficiary.email ||
      !beneficiary.phone
    ) {
      alert("Please fill in all required fields.");
      return;
    }

    setStep(2);
  };

  const previousStep = () => {
    setStep(1);
  };

  const handleSave = () => {
    const data = {
      ...beneficiary,
      documents,
    };

    console.log(data);

    alert("Beneficiary Added Successfully!");

    setBeneficiary({
      profilePicture: null,
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      dob: "",
      gender: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
      joiningDate: "",
    });

    setDocuments({
      aadhaar: null,
      addressProof: null,
      birthCertificate: null,
    });

    setStep(1);
  };

  return (
    <Layout title="Add Beneficiary">
      <div className="add-beneficiary-page">

        <div className="page-header">
          <h2>Add Beneficiary</h2>
          <p>Fill in the beneficiary details below.</p>
        </div>

        <div className="beneficiary-card">

          {/* Step Navigation */}

          <div className="step-navigation">

            <div
              className={`step-item ${step === 1 ? "active" : ""}`}
            >
              <div className="step-circle">1</div>

              <div>
                <h4>Personal Details</h4>
                <span>Basic Information</span>
              </div>
            </div>

            <div className="step-divider"></div>

            <div
              className={`step-item ${step === 2 ? "active" : ""}`}
            >
              <div className="step-circle">2</div>

              <div>
                <h4>Documents</h4>
                <span>Upload Documents</span>
              </div>
            </div>

          </div>

          <div className="step-content">

            {step === 1 ? (
              <PersonalDetails
                beneficiary={beneficiary}
                setBeneficiary={setBeneficiary}
                nextStep={nextStep}
              />
            ) : (
              <DocumentsUpload
                documents={documents}
                setDocuments={setDocuments}
                previousStep={previousStep}
                handleSave={handleSave}
              />
            )}

          </div>

        </div>

      </div>
    </Layout>
  );
}
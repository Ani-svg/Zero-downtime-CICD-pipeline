import { NavLink } from "react-router-dom";
import "./Sidebar.css";
import {
  FaHome,
  FaUsers,
  FaUserFriends,
  FaClipboardList,
  FaCog,
} from "react-icons/fa";

export default function Sidebar() {
  return (
    <div className="sidebar">

      <div className="logo">
        <h2>Women for Girls NGO</h2>
      </div>

      <nav>

        <NavLink to="/dashboard" className="menu-item">
          <FaHome />
          <span>Dashboard</span>
        </NavLink>

        <NavLink to="/beneficiaries" className="menu-item">
          <FaUsers />
          <span>Beneficiaries</span>
        </NavLink>

        <NavLink to="/mentors" className="menu-item">
          <FaUserFriends />
          <span>Mentors</span>
        </NavLink>

        <NavLink to="/reports" className="menu-item">
          <FaClipboardList />
          <span>Reports</span>
        </NavLink>

        <NavLink to="/settings" className="menu-item">
          <FaCog />
          <span>Settings</span>
        </NavLink>

      </nav>

    </div>
  );
}
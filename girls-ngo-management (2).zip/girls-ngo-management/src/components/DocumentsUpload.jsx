import "./DocumentsUpload.css";
import { FaCloudUploadAlt, FaFileAlt } from "react-icons/fa";

export default function DocumentsUpload({
  documents,
  setDocuments,
  previousStep,
  handleSave,
}) {
  const handleFile = (e) => {
    const { name, files } = e.target;

    setDocuments({
      ...documents,
      [name]: files[0],
    });
  };

  const UploadBox = ({ title, name }) => (
    <div className="upload-card">
      <h3>{title}</h3>

      <label className="upload-area">
        <FaCloudUploadAlt size={40} className="upload-icon" />

        <p>Drag & Drop</p>
        <span>or Click to Browse</span>

        <input
          type="file"
          hidden
          name={name}
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={handleFile}
        />
      </label>

      {documents[name] && (
        <div className="file-preview">
          <FaFileAlt />
          <span>{documents[name].name}</span>
        </div>
      )}
    </div>
  );

  return (
    <div className="documents-page">

      <h2>Upload Documents</h2>

      <div className="documents-grid">

        <UploadBox
          title="Aadhaar Card"
          name="aadhaar"
        />

        <UploadBox
          title="Address Proof"
          name="addressProof"
        />

        <UploadBox
          title="Birth Certificate"
          name="birthCertificate"
        />

      </div>

      <div className="button-row">

        <button
          className="back-btn"
          onClick={previousStep}
        >
          ← Back
        </button>

        <button
          className="save-btn"
          onClick={handleSave}
        >
          Save Beneficiary
        </button>

      </div>

    </div>
  );
}
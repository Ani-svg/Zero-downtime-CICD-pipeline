import "./PersonalDetails.css";
import { FaCamera } from "react-icons/fa";

export default function PersonalDetails({
  beneficiary,
  setBeneficiary,
  nextStep,
}) {

  const handleChange = (e) => {
    setBeneficiary({
      ...beneficiary,
      [e.target.name]: e.target.value,
    });
  };

  const handleImage = (e) => {
    setBeneficiary({
      ...beneficiary,
      profilePicture: e.target.files[0],
    });
  };

  return (
    <div className="personal-details">

      <div className="profile-section">

        <div className="profile-picture">

          {beneficiary.profilePicture ? (
            <img
              src={URL.createObjectURL(beneficiary.profilePicture)}
              alt="profile"
            />
          ) : (
            <div className="placeholder">
              <FaCamera size={35} />
            </div>
          )}

        </div>

        <label className="upload-btn">
          Upload Profile Picture
          <input
            type="file"
            accept="image/*"
            hidden
            onChange={handleImage}
          />
        </label>

      </div>

      <div className="form-grid">

        <div>
          <label>First Name</label>
          <input
            type="text"
            name="firstName"
            value={beneficiary.firstName}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Last Name</label>
          <input
            type="text"
            name="lastName"
            value={beneficiary.lastName}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={beneficiary.email}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Phone Number</label>
          <input
            type="text"
            name="phone"
            value={beneficiary.phone}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Date of Birth</label>
          <input
            type="date"
            name="dob"
            value={beneficiary.dob}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Gender</label>
          <select
            name="gender"
            value={beneficiary.gender}
            onChange={handleChange}
          >
            <option value="">Choose</option>
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>

        <div className="full-width">
          <label>Address</label>
          <textarea
            rows="3"
            name="address"
            value={beneficiary.address}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>City</label>
          <input
            type="text"
            name="city"
            value={beneficiary.city}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>State</label>
          <input
            type="text"
            name="state"
            value={beneficiary.state}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Pincode</label>
          <input
            type="text"
            name="pincode"
            value={beneficiary.pincode}
            onChange={handleChange}
          />
        </div>

        <div>
          <label>Date of Joining</label>
          <input
            type="date"
            name="joiningDate"
            value={beneficiary.joiningDate}
            onChange={handleChange}
          />
        </div>

      </div>

      <div className="button-area">
        <button className="next-btn" onClick={nextStep}>
          Next →
        </button>
      </div>

    </div>
  );
}